"""生成本工具自己的合成 CSV/XLSX 测试输入。只写指定新目录。"""
from __future__ import annotations
import argparse
import csv
from datetime import datetime
from pathlib import Path
from openpyxl import Workbook


def make_demo(directory: Path) -> tuple[Path, Path]:
    directory.mkdir(parents=True, exist_ok=False)
    csv_path = directory / "synthetic_orders.csv"
    with csv_path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["订单号", "日期", "渠道", "金额", "状态", "备注"])
        writer.writerows([
            ["A001", "2026-10-01", "线上", "￥1,200.00", "已支付", "=2+2"],
            ["A002", "2026/10/02", "门店", "0.00", "已支付", "第一行\n第二行"],
            ["A003", "2026-02-30", "门店", "19.90", "已支付", "不存在的日期"],
            ["A004", "2026-10-04", "线上", "50.00", "已支付", "跨文件冲突"],
            ["A005", "2026-10-05", "线上", "1,20.00", "已支付", "千位分组错误"],
            [],
            ["A006", "2026-10-06", "门店", "-5.00", "已支付", "未允许负数"],
        ])
    book = Workbook()
    sheet = book.active
    sheet.title = "Orders"
    sheet.append(["ID", "Date", "Channel", "Amount", "Status", "Note"])
    for row in [
        ["A001", datetime(2026, 10, 1), "线上", 1200, "已支付", "=2+2"],
        ["A004", datetime(2026, 10, 4), "线上", 60, "已支付", "跨文件冲突"],
        ["A008", datetime(2026, 10, 8), "门店", 80, "已退款", "@meeting"],
        ["A009", datetime(2026, 10, 9), "线上", "=1+1", "已支付", "公式金额应隔离"],
        [123, datetime(2026, 10, 10), "门店", 7, "已支付", "数值ID不猜前导零"],
        ["A010", datetime(2026, 10, 10, 14), "门店", 25, "已支付", "非零时间不自动丢弃"],
        ["=SAFE", datetime(2026, 10, 11), "线上", 12.30, "已支付", "文本ID保持文本"],
    ]:
        sheet.append(row)
    sheet["F2"].data_type = "s"
    sheet["A8"].data_type = "s"
    ignored = book.create_sheet("NotSelected")
    ignored.append(["本表未被规则选择，不应读取"])
    xlsx_path = directory / "synthetic_orders.xlsx"
    book.save(xlsx_path)
    return csv_path, xlsx_path


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=Path(__file__).with_name("examples") / "data")
    args = parser.parse_args()
    paths = make_demo(args.out)
    print("合成演示输入已生成：", *paths, sep="\n")
