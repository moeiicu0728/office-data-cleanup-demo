"""按显式 JSON 规则整理 CSV/XLSX；不改源文件，不猜测列或业务口径。"""
from __future__ import annotations

import argparse
import codecs
import csv
import hashlib
import json
import math
import os
import re
import sys
import unicodedata
import uuid
from collections import defaultdict
from datetime import date, datetime, time, timedelta
from decimal import Decimal, InvalidOperation, localcontext
from pathlib import Path

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.cell.cell import ILLEGAL_CHARACTERS_RE

VERSION = "1.0.0"
META = ["__ref", "__source_id", "__file", "__sheet", "__record", "__row_start", "__row_end"]
DISPOSITIONS = ("clean", "exception", "duplicate", "blank_skipped")
OUTPUT_FILES = ["clean.csv", "exceptions.csv", "duplicates.csv", "ledger.csv", "raw_records.csv", "group_summary.csv", "audit.json", "report.xlsx", "rules_used.json"]


class InputError(ValueError):
    """源结构、配置或整批处理错误。不会把配置错误伪装成数据异常。"""


def jsonable(value):
    if isinstance(value, Decimal):
        return format(value, "f")
    if isinstance(value, (date, datetime)):
        return value.isoformat()
    if isinstance(value, time):
        return {"excel_time": value.isoformat()}
    if isinstance(value, timedelta):
        return {"excel_timedelta": {"days": value.days, "seconds": value.seconds, "microseconds": value.microseconds}}
    if isinstance(value, dict):
        return {str(k): jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [jsonable(v) for v in value]
    if isinstance(value, float) and not math.isfinite(value):
        return {"non_finite_number": str(value)}
    return value


def dumps(value) -> str:
    return json.dumps(jsonable(value), ensure_ascii=False, allow_nan=False, separators=(",", ":"))


def digest(path: Path) -> str:
    hasher = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            hasher.update(chunk)
    return hasher.hexdigest()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise InputError(message)


def check_keys(data: dict, allowed: set[str], label: str) -> None:
    require(isinstance(data, dict), f"{label} 必须是对象")
    unknown = set(data) - allowed
    require(not unknown, f"{label} 含未知配置项：{sorted(unknown)}")


def validate_config(config: dict) -> dict:
    check_keys(config, {"version", "notice", "columns", "sources", "primary_key", "amount_totals", "group_by", "limits", "csv_text_safety"}, "配置")
    require(config.get("version") == 1, "配置 version 必须为 1")
    require(config.get("csv_text_safety") in {"excel_safe", "raw"}, "csv_text_safety 必须明确 excel_safe 或 raw")
    columns = config.get("columns")
    require(isinstance(columns, list) and columns, "columns 必须为非空列表")
    names = []
    for col in columns:
        check_keys(col, {"name", "type", "required", "trim", "allow_numeric_to_text", "allowed_values", "formats", "accept_excel_dates", "allow_time_drop", "decimal_places", "decimal_separator", "thousands_separator", "prefixes", "suffixes", "allow_negative"}, "列规则")
        name = col.get("name")
        require(isinstance(name, str) and name.strip() and not name.startswith("__"), "列名必须为非空文本且不能以 __ 开头")
        require(name not in names, f"重复目标列：{name}")
        names.append(name)
        kind = col.get("type")
        require(kind in {"text", "date", "decimal"}, f"{name} 的 type 仅支持 text/date/decimal")
        for option in ("required", "trim", "allow_numeric_to_text", "accept_excel_dates", "allow_time_drop", "allow_negative"):
            require(option not in col or isinstance(col[option], bool), f"{name}.{option} 必须为布尔值")
        if "allowed_values" in col:
            require(kind == "text" and isinstance(col["allowed_values"], list) and all(isinstance(v, str) for v in col["allowed_values"]), f"{name}.allowed_values 必须为文本列表，且仅用于 text")
        if kind == "date":
            formats = col.get("formats")
            require(isinstance(formats, list) and formats and all(isinstance(fmt, str) and fmt for fmt in formats), f"{name} 必须明确给出 formats")
            # 先验证格式指令，不让拼写错误造成整列隔离。日期必须含年份，避免自动补 1900 年。
            for fmt in formats:
                directives = re.findall(r"%([A-Za-z%])", fmt)
                require(all(token in directives for token in ("Y", "m", "d")), f"{name} 的日期格式必须含完整 %Y、%m、%d，不能补造月日：{fmt}")
                try:
                    sample = datetime(2024, 11, 23, 14, 35, 46).strftime(fmt)
                    datetime.strptime(sample, fmt)
                except (ValueError, TypeError, re.error) as exc:
                    raise InputError(f"{name} 的日期格式不合法：{fmt}") from exc
        if kind == "decimal":
            places = col.get("decimal_places")
            require(isinstance(places, int) and not isinstance(places, bool) and 0 <= places <= 8, f"{name} 必须给出 0–8 的 decimal_places")
            dec = col.get("decimal_separator")
            sep = col.get("thousands_separator")
            require(isinstance(dec, str) and len(dec) == 1 and dec in {".", ","}, f"{name} 必须明确 decimal_separator 为 . 或 ,")
            require(sep is None or isinstance(sep, str) and len(sep) == 1 and sep not in "0123456789+-", f"{name}.thousands_separator 必须为单字符或 null")
            require(dec != sep, f"{name} 的小数点和千位分隔符不能相同")
            for key in ("prefixes", "suffixes"):
                values = col.get(key, [])
                require(isinstance(values, list) and all(isinstance(x, str) and x for x in values), f"{name}.{key} 必须为非空文本组成的列表")
    primary = config.get("primary_key")
    require(isinstance(primary, list) and primary and len(set(primary)) == len(primary) and all(n in names for n in primary), "primary_key 必须为不重复的目标列名列表，不能为空")
    amount_names = config.get("amount_totals")
    require(isinstance(amount_names, list) and len(set(amount_names)) == len(amount_names), "amount_totals 必须明确给出列表（可为空）")
    for name in amount_names:
        require(any(c["name"] == name and c["type"] == "decimal" for c in columns), f"amount_totals 不是 decimal 列：{name}")
    groups = config.get("group_by")
    require(isinstance(groups, list) and len(set(groups)) == len(groups) and all(n in names for n in groups), "group_by 必须明确给出列名列表（可为空）")
    profiles = config.get("sources")
    require(isinstance(profiles, dict) and profiles, "sources 必须为非空对象")
    for alias, profile in profiles.items():
        require(isinstance(alias, str) and alias and "=" not in alias, "来源配置名不能包含 =")
        check_keys(profile, {"column_map", "header_row", "blank_rows", "csv", "xlsx"}, f"sources.{alias}")
        mapping = profile.get("column_map")
        require(isinstance(mapping, dict) and mapping and all(isinstance(k, str) and k and v in names for k, v in mapping.items()), f"{alias}.column_map 必须是源表头到目标列名的映射")
        require(len(set(mapping.values())) == len(mapping), f"{alias} 多个源列映射到相同目标列")
        require(all(c["name"] in mapping.values() for c in columns if c.get("required") or c["name"] in primary), f"{alias} 缺少必填列或主键列的映射")
        require(isinstance(profile.get("header_row"), int) and not isinstance(profile["header_row"], bool) and profile["header_row"] >= 1, f"{alias}.header_row 必须为从 1 开始的行/记录号")
        require(profile.get("blank_rows") in {"skip", "quarantine"}, f"{alias}.blank_rows 必须明确 skip 或 quarantine")
        if "csv" in profile:
            check_keys(profile["csv"], {"encoding", "delimiter"}, f"{alias}.csv")
            encoding = profile["csv"].get("encoding")
            delimiter = profile["csv"].get("delimiter")
            require(isinstance(encoding, str) and encoding, f"{alias}.csv 必须给出 encoding")
            try:
                codecs.lookup(encoding)
            except LookupError as exc:
                raise InputError(f"不支持编码：{encoding}") from exc
            require(isinstance(delimiter, str) and len(delimiter) == 1 and delimiter not in "\r\n\"", f"{alias}.csv 必须明确单字符 delimiter")
        if "xlsx" in profile:
            check_keys(profile["xlsx"], {"sheets", "formula_policy"}, f"{alias}.xlsx")
            sheets = profile["xlsx"].get("sheets")
            require(isinstance(sheets, list) and sheets and all(isinstance(s, str) and s for s in sheets) and len(set(sheets)) == len(sheets), f"{alias}.xlsx 必须明确 sheets，不能自动选择活动表")
            require(profile["xlsx"].get("formula_policy") == "reject", f"{alias}.xlsx.formula_policy 必须为 reject，不读取可能过期的公式缓存")
        require("csv" in profile or "xlsx" in profile, f"{alias} 至少配置 csv 或 xlsx")
    limits = config.get("limits", {})
    check_keys(limits, {"max_rows", "max_columns", "max_file_bytes"}, "limits")
    for key, default in (("max_rows", 100000), ("max_columns", 256), ("max_file_bytes", 50 * 1024 * 1024)):
        require(isinstance(limits.get(key, default), int) and not isinstance(limits.get(key, default), bool) and limits.get(key, default) > 0, f"limits.{key} 必须为正整数")
    return config


def blank(value) -> bool:
    return value is None or isinstance(value, str) and not value.strip()


def parse_decimal_raw(value, rule: dict) -> Decimal:
    """仅解析明确格式，不因负数/小数位业务校验失败丢失可核对的原始金额。"""
    if isinstance(value, bool) or not isinstance(value, (str, int, float, Decimal)):
        raise ValueError("金额类型不受支持")
    if isinstance(value, str):
        text = value.strip() if rule.get("trim") else value
        for token in sorted(rule.get("prefixes", []), key=len, reverse=True):
            if text.startswith(token):
                text = text[len(token):]
                text = text.strip() if rule.get("trim") else text
                break
        for token in sorted(rule.get("suffixes", []), key=len, reverse=True):
            if text.endswith(token):
                text = text[:-len(token)]
                text = text.strip() if rule.get("trim") else text
                break
        sep = rule.get("thousands_separator")
        integer = rf"(?:[0-9]+|[0-9]{{1,3}}(?:{re.escape(sep)}[0-9]{{3}})+)" if sep else r"[0-9]+"
        pattern = rf"[+-]?{integer}(?:{re.escape(rule['decimal_separator'])}[0-9]+)?"
        if not re.fullmatch(pattern, text):
            raise ValueError("金额不匹配已声明符号/分隔符/分组格式")
        if sep:
            text = text.replace(sep, "")
        text = text.replace(rule["decimal_separator"], ".")
    else:
        text = str(value)
    try:
        number = Decimal(text)
        if not number.is_finite():
            raise ValueError("金额必须为有限数")
        if len(number.as_tuple().digits) > 30 or number.adjusted() > 29:
            raise ValueError("金额超过本工具 30 位精度支持范围，已隔离")
        return number
    except InvalidOperation as exc:
        raise ValueError("金额无法按明确格式解析") from exc


def normalize(value, rule: dict):
    if blank(value):
        if rule.get("required"):
            raise ValueError("必填值缺失")
        return None
    kind = rule["type"]
    if kind == "text":
        if not isinstance(value, str):
            if not rule.get("allow_numeric_to_text") or isinstance(value, bool) or not isinstance(value, (int, float, Decimal)):
                raise ValueError("期望文本，源为数值/其他类型；未猜测前导零或显示格式")
            if isinstance(value, float) and not math.isfinite(value):
                raise ValueError("非有限数值不能转换为文本")
            value = str(value)
        if rule.get("trim"):
            value = value.strip()
        if "allowed_values" in rule and value not in rule["allowed_values"]:
            raise ValueError("值不在明确给定的 allowed_values 中")
        return value
    if kind == "date":
        if isinstance(value, (date, datetime)):
            if not rule.get("accept_excel_dates"):
                raise ValueError("原生 Excel 日期未获 accept_excel_dates 授权")
            parsed = value if isinstance(value, datetime) else datetime.combine(value, time())
        elif isinstance(value, str):
            text = value.strip() if rule.get("trim") else value
            matches = []
            for fmt in rule["formats"]:
                try:
                    matches.append(datetime.strptime(text, fmt))
                except ValueError:
                    continue
            if not matches:
                raise ValueError("日期不存在或不匹配已声明格式，未猜测日期顺序")
            if len({m.isoformat() for m in matches}) > 1:
                raise ValueError("多个已声明日期格式给出不同结果，需明确口径")
            parsed = matches[0]
        else:
            raise ValueError("未把普通数字猜测为 Excel 日期序号")
        if parsed.time() != time() and not rule.get("allow_time_drop"):
            raise ValueError("日期值含非零时间，未获 allow_time_drop 授权")
        return parsed.date()
    try:
        number = parse_decimal_raw(value, rule)
        if number < 0 and not rule.get("allow_negative"):
            raise ValueError("负金额未获 allow_negative 授权")
        quantum = Decimal(1).scaleb(-rule["decimal_places"])
        with localcontext() as ctx:
            ctx.prec = 80
            quantized = number.quantize(quantum)
        if quantized != number:
            raise ValueError("金额小数位超过规则，未擅自四舍五入")
        return quantized
    except InvalidOperation as exc:
        raise ValueError("金额无法按明确精度解析") from exc


def header_check(headers: list, mapping: dict, label: str, max_columns: int) -> list[str]:
    require(len(headers) <= max_columns, f"{label} 表头超过 max_columns")
    require(headers and all(isinstance(h, str) and h for h in headers), f"{label} 存在空白或非文本表头")
    require(len(set(headers)) == len(headers), f"{label} 存在重复表头，未自动重命名")
    require(set(mapping) <= set(headers), f"{label} 缺少明确映射的源列：{sorted(set(mapping)-set(headers))}")
    return headers


def parse_inputs(inputs: list[str], config: dict) -> list[tuple[str, Path]]:
    parsed = []
    seen = set()
    for spec in inputs:
        require("=" in spec, "--input 格式必须为 配置名=文件路径")
        alias, text = spec.split("=", 1)
        require(alias in config["sources"], f"未知来源配置名：{alias}")
        path = Path(text).expanduser().resolve()
        require(path.is_file(), f"输入文件不存在：{text}")
        require(path not in seen, f"同一文件重复输入：{text}")
        seen.add(path)
        require(path.suffix.lower() in {".csv", ".xlsx"}, f"仅支持 .csv / .xlsx：{path.name}")
        kind = path.suffix[1:].lower()
        require(kind in config["sources"][alias], f"来源配置 {alias} 未声明 {kind} 读取规则")
        parsed.append((alias, path))
    return parsed


def read_sources(inputs: list[tuple[str, Path]], config: dict) -> tuple[list[dict], list[dict]]:
    limits = config.get("limits", {})
    max_rows = limits.get("max_rows", 100000)
    max_cols = limits.get("max_columns", 256)
    max_bytes = limits.get("max_file_bytes", 50 * 1024 * 1024)
    rows, manifest = [], []

    def add(source, sheet, record, start, end, headers, values, formula_columns, profile):
        require(len(rows) < max_rows, f"全部来源记录数超过 max_rows={max_rows}；整批停止，未截断结果")
        ref = f"{source['source_id']}:{sheet or 'CSV'}:{record}"
        raw = {"headers": headers, "values": jsonable(values), "value_types": [type(v).__name__ for v in values], "formula_columns": formula_columns}
        issues = []
        normalized = {}
        parsed_amounts = {}
        if len(values) != len(headers):
            issues.append({"column": None, "code": "field_count", "message": f"源记录字段数 {len(values)} 与表头 {len(headers)} 不同"})
        if formula_columns:
            issues.append({"column": None, "code": "formula", "message": f"源公式单元格已隔离，未执行或读取缓存：{formula_columns}"})
        index = {h: i for i, h in enumerate(headers)}
        reverse = {v: k for k, v in profile["column_map"].items()}
        for rule in config["columns"]:
            name = rule["name"]
            src = reverse.get(name)
            value = values[index[src]] if src in index and index[src] < len(values) else None
            if rule["type"] == "decimal":
                parsed_amounts[name] = None
                if not blank(value) and src not in formula_columns:
                    try:
                        parsed_amounts[name] = parse_decimal_raw(value, rule)
                    except ValueError:
                        pass
            if src in formula_columns:
                normalized[name] = None
                issues.append({"column": name, "code": "formula", "message": "映射源值为公式，未执行或猜测缓存值"})
                continue
            try:
                normalized[name] = normalize(value, rule)
                if name in config["primary_key"] and normalized[name] is None:
                    raise ValueError("主键值缺失")
            except ValueError as exc:
                normalized[name] = None
                issues.append({"column": name, "code": "invalid_value", "message": str(exc)})
        is_blank = all(blank(v) for v in values)
        row = {"ref": ref, "source_id": source["source_id"], "file": source["file_name"], "sheet": sheet, "record": record, "row_start": start, "row_end": end, "raw": raw, "normalized": normalized, "parsed_amounts": parsed_amounts, "issues": issues, "is_blank": is_blank, "blank_policy": profile["blank_rows"]}
        rows.append(row)
        source["record_count"] += 1

    for number, (alias, path) in enumerate(inputs, 1):
        require(path.stat().st_size <= max_bytes, f"{path.name} 超过 max_file_bytes={max_bytes}")
        source = {"source_id": f"S{number:03}", "file_name": path.name, "profile": alias, "sha256_before": digest(path), "bytes": path.stat().st_size, "record_count": 0, "sheets": []}
        profile = config["sources"][alias]
        if path.suffix.lower() == ".csv":
            opts = profile["csv"]
            with path.open("r", encoding=opts["encoding"], newline="") as stream:
                reader = csv.reader(stream, delimiter=opts["delimiter"], strict=True)
                headers = None
                last_line = 0
                try:
                    for record, values in enumerate(reader, 1):
                        start, end = last_line + 1, reader.line_num
                        last_line = end
                        if record < profile["header_row"]:
                            continue
                        if record == profile["header_row"]:
                            headers = header_check(values, profile["column_map"], path.name, max_cols)
                            source["headers"] = headers
                            continue
                        add(source, "", record, start, end, headers, values, [], profile)
                except (csv.Error, UnicodeError) as exc:
                    raise InputError(f"{path.name} CSV 语法/编码错误：{exc}，整批停止") from exc
                require(headers is not None, f"{path.name} 未找到 header_row={profile['header_row']}")
        else:
            book = load_workbook(path, read_only=True, data_only=False, keep_links=False)
            try:
                for sheet_name in profile["xlsx"]["sheets"]:
                    require(sheet_name in book.sheetnames, f"{path.name} 中不存在明确指定的工作表：{sheet_name}")
                    sheet = book[sheet_name]
                    require(sheet.max_column <= max_cols, f"{path.name}/{sheet_name} 使用范围超过 max_columns={max_cols}（含格式化列），请先明确源范围")
                    source["sheets"].append(sheet_name)
                    headers = None
                    for row_number, cells in enumerate(sheet.iter_rows(), 1):
                        if row_number < profile["header_row"]:
                            continue
                        values = [c.value for c in cells]
                        if row_number == profile["header_row"]:
                            while values and values[-1] is None:
                                values.pop()
                            require(not any(c.data_type == "f" for c in cells), f"{path.name}/{sheet_name} 表头含公式")
                            headers = header_check(values, profile["column_map"], f"{path.name}/{sheet_name}", max_cols)
                            source.setdefault("sheet_headers", {})[sheet_name] = headers
                            continue
                        while len(values) > len(headers) and values[-1] is None:
                            values.pop()
                        formula_columns = [headers[i] if i < len(headers) else f"未命名列{i+1}" for i, c in enumerate(cells) if c.data_type == "f"]
                        add(source, sheet_name, row_number, row_number, row_number, headers, values, formula_columns, profile)
                    require(headers is not None, f"{path.name}/{sheet_name} 未找到指定表头行")
            finally:
                book.close()
        source["sha256_after"] = digest(path)
        require(source["sha256_after"] == source["sha256_before"], f"读取期间源文件发生变化：{path.name}；整批停止")
        manifest.append(source)
    return rows, manifest


def classify(rows: list[dict], config: dict) -> None:
    by_key = defaultdict(list)
    names = [c["name"] for c in config["columns"]]
    for row in rows:
        row["disposition"] = "blank_skipped" if row["is_blank"] and row["blank_policy"] == "skip" else "exception" if row["issues"] else "clean"
        if row["disposition"] == "blank_skipped":
            continue
        key = tuple(row["normalized"][name] for name in config["primary_key"])
        key_has_error = any(i["column"] in config["primary_key"] for i in row["issues"])
        if any(value is None for value in key) or key_has_error:
            continue
        by_key[key].append(row)
    for key, group in by_key.items():
        fingerprints = set()
        for row in group:
            # 异常字段也纳入冲突比较，防止先排除坏行后把同主键合法行错误放行。
            errors = {i["column"] for i in row["issues"] if i["column"]}
            mapped_values = dict(zip(row["raw"]["headers"], row["raw"]["values"]))
            raw_targets = {target: mapped_values.get(src) for src, target in config["sources"][next(s["profile"] for s in config["_manifest"] if s["source_id"] == row["source_id"])]["column_map"].items()}
            record = [({"invalid_raw": raw_targets.get(name)} if name in errors else row["normalized"][name]) for name in names]
            fingerprints.add(dumps(record))
        if len(fingerprints) > 1:
            for row in group:
                row["disposition"] = "exception"
                row["issues"].append({"column": None, "code": "primary_key_conflict", "message": "同主键的标准化业务字段不一致，相关记录全部隔离"})
        else:
            eligible = [r for r in group if not r["issues"]]
            if eligible:
                kept = eligible[0]
                for row in eligible[1:]:
                    row["disposition"] = "duplicate"
                    row["kept_ref"] = kept["ref"]


def reconcile(rows: list[dict], manifest: list[dict], config: dict) -> dict:
    counts = {kind: sum(r["disposition"] == kind for r in rows) for kind in DISPOSITIONS}
    require(len(rows) == sum(counts.values()), "内部错误：行数不守恒")
    amount_reconciliation = {}
    with localcontext() as ctx:
        ctx.prec = 80
        for name in config["amount_totals"]:
            values = [r["parsed_amounts"][name] for r in rows]
            known = [v for v in values if isinstance(v, Decimal)]
            parts = {kind: sum((r["parsed_amounts"][name] for r in rows if r["disposition"] == kind and isinstance(r["parsed_amounts"][name], Decimal)), Decimal(0)) for kind in DISPOSITIONS}
            total = sum(known, Decimal(0))
            check = sum(parts.values(), Decimal(0)) == total
            require(check, f"内部错误：{name} 金额不守恒")
            amount_reconciliation[name] = {"known_input_total": total, "known_input_count": len(known), "unavailable_input_count": len(rows)-len(known), "partition_totals": parts, "difference": total-sum(parts.values(), Decimal(0)), "reconciled": check}
        grouped = defaultdict(list)
        if config["group_by"]:
            for row in rows:
                if row["disposition"] == "clean":
                    grouped[tuple(row["normalized"][n] for n in config["group_by"])].append(row)
        group_summary = []
        for key, group in sorted(grouped.items(), key=lambda pair: dumps(pair[0])):
            group_summary.append({"groups": dict(zip(config["group_by"], key)), "record_count": len(group), "totals": {n: sum((r["normalized"][n] for r in group if isinstance(r["normalized"][n], Decimal)), Decimal(0)) for n in config["amount_totals"]}, "missing_amount_counts": {n: sum(r["normalized"][n] is None for r in group) for n in config["amount_totals"]}})
    return {"tool_version": VERSION, "notice": config.get("notice", ""), "snapshot_report": True, "source_record_count": len(rows), "counts": counts, "row_reconciled": True, "amount_reconciliation": amount_reconciliation, "group_by": config["group_by"], "group_summary": group_summary, "sources": manifest, "records": rows, "export_notes": {"csv_text_safety_policy": config["csv_text_safety"], "csv_text_safety_prefixes": 0, "csv_escaped_cells": [], "xlsx_text_escapes": [], "xlsx_decimal_as_text": []}, "limitations": ["金额核对仅覆盖可解析的源金额；不可解析或缺失金额单列计数，没有按零补齐。", "金额汇总不代表销售收入、收款或净收入；按配置列及分组机械汇总。", "报告为本次运行快照，修改 Excel 后不会自动重新清洗或核对。", "源文件已经以数值保存的长标识符和前导零无法恢复；默认文本列拒绝数值输入。"]}


def metadata(row: dict) -> list:
    return [row["ref"], row["source_id"], row["file"], row["sheet"], row["record"], row["row_start"], row["row_end"]]


def csv_value(value, notes: dict, location: str):
    if isinstance(value, (Decimal, date, datetime)):
        return jsonable(value)
    if isinstance(value, (dict, list)):
        value = dumps(value)
    if notes["csv_text_safety_policy"] == "excel_safe" and isinstance(value, str) and value and (value[0] in "=+-@\t\r\n" or value.lstrip(" \t\r\n").startswith(("=", "+", "-", "@"))):
        notes["csv_text_safety_prefixes"] += 1
        notes["csv_escaped_cells"].append(location)
        return "'" + value
    return value


def write_csv(path: Path, headers: list[str], data: list[list], notes: dict) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.writer(stream)
        for r, row in enumerate([headers, *data], 1):
            writer.writerow([csv_value(v, notes, f"{path.name}!R{r}C{c}") for c, v in enumerate(row, 1)])


def write_workbook(path: Path, tables: dict, audit: dict, config: dict) -> None:
    notes = audit["export_notes"]

    def append(sheet, values):
        safe = []
        for column, value in enumerate(values, 1):
            changes = []
            if isinstance(value, str):
                if ILLEGAL_CHARACTERS_RE.search(value):
                    value = ILLEGAL_CHARACTERS_RE.sub(lambda m: f"\\u{ord(m.group()):04x}", value)
                    changes.append("XML控制字符转义；完整原值见CSV/audit")
                if len(value) > 32767:
                    value = "文本超过 Excel 单元格上限，完整值见同来源记录的 CSV / audit.json。"
                    changes.append("超长文本改为完整值引用")
            safe.append(value)
            if changes:
                notes["xlsx_text_escapes"].append({"cell": f"{sheet.title}!R{sheet.max_row+1}C{column}", "changes": changes})
        sheet.append(safe)
    book = Workbook()
    summary = book.active
    summary.title = "汇总"
    append(summary, ["按明确规则整理的数据快照"])
    append(summary, [config.get("notice", "") or "数据口径由 rules_used.json 指定，未推断业务含义。"])
    append(summary, ["原始记录", audit["source_record_count"], "干净", audit["counts"]["clean"], "异常", audit["counts"]["exception"], "重复", audit["counts"]["duplicate"], "跳过空行", audit["counts"]["blank_skipped"]])
    append(summary, ["行数核对", "守恒"])
    append(summary, ["金额列", "可解析原始金额", "干净记录金额", "异常中可解析金额", "重复金额", "跳过空行金额", "差额", "无法解析/缺失笔数"])
    for name, check in audit["amount_reconciliation"].items():
        append(summary, [name, check["known_input_total"], *[check["partition_totals"][k] for k in DISPOSITIONS], check["difference"], check["unavailable_input_count"]])
    append(summary, ["金额说明", "仅核对可解析金额，不把未知金额补零。不推断收入、收款或退款口径。"])
    append(summary, ["来源说明", "来源编号、文件 SHA-256、工作表、记录号和物理行号见 audit.json 与逐行去向。"])
    append(summary, ["报告说明", "静态结果；更改来源或规则后，请在新的输出目录重新运行。"])
    if config["group_by"]:
        append(summary, [])
        append(summary, ["仅干净记录的分组汇总"])
        for row in [tables["group_summary"][0], *tables["group_summary"][1]]:
            append(summary, row)
    sheet_names = {"clean": "清洗结果", "exceptions": "待确认", "duplicates": "重复记录", "ledger": "逐行去向", "raw_records": "原始记录"}
    for key, name in sheet_names.items():
        sheet = book.create_sheet(name)
        headers, data = tables[key]
        append(sheet, headers)
        for values in data:
            append(sheet, values)
        sheet.freeze_panes = "H2" if len(headers) > 7 else "A2"
        sheet.auto_filter.ref = sheet.dimensions
        sheet.sheet_view.showGridLines = False
    notes = audit["export_notes"]
    for sheet in book:
        sheet.sheet_view.showGridLines = False
        for row in sheet:
            for cell in row:
                value = cell.value
                if isinstance(value, Decimal):
                    number = float(value)
                    if len(value.normalize().as_tuple().digits) <= 15 and math.isfinite(number) and Decimal(str(number)) == value:
                        cell.value = number
                        cell.number_format = '#,##0.00######'
                    else:
                        cell.value = format(value, "f")
                        cell.data_type = "s"
                        notes["xlsx_decimal_as_text"].append(f"{sheet.title}!{cell.coordinate}")
                elif isinstance(value, str):
                    changes = []
                    if ILLEGAL_CHARACTERS_RE.search(value):
                        value = ILLEGAL_CHARACTERS_RE.sub(lambda m: f"\\u{ord(m.group()):04x}", value)
                        changes.append("XML控制字符转义")
                    if len(value) > 32767:
                        value = "文本超过 Excel 单元格上限，完整值见同来源记录的 CSV / audit.json。"
                        changes.append("超长文本改为完整值引用")
                    cell.value = value
                    cell.data_type = "s"  # 以 = 开头的源文本也不会成为输出公式。
                    if changes:
                        notes["xlsx_text_escapes"].append({"cell": f"{sheet.title}!{cell.coordinate}", "changes": changes})
                elif isinstance(value, (dict, list)):
                    raise InputError("内部错误：Excel 结果包含未序列化结构")
                elif isinstance(value, date):
                    if value.year < 1900:
                        cell.value = value.isoformat()
                        cell.data_type = "s"
                        notes["xlsx_text_escapes"].append({"cell": f"{sheet.title}!{cell.coordinate}", "changes": ["1900年前日期以ISO文本保留"]})
                    else:
                        cell.number_format = "yyyy-mm-dd"
                cell.font = Font(name="Arial", size=10, color="172A3A")
                cell.alignment = Alignment(vertical="center")
        for cell in sheet[1]:
            cell.font = Font(name="Arial", size=10, bold=True, color="FFFFFF")
            cell.fill = PatternFill("solid", fgColor="24486A")
        for column in sheet.columns:
            letter = column[0].column_letter
            width = max((min(max((sum(2 if unicodedata.east_asian_width(ch) in "WF" else 1 for ch in line) for line in str(c.value if c.value is not None else "").splitlines()), default=0), 42) for c in column), default=10) + 2
            sheet.column_dimensions[letter].width = max(12, min(width, 44))
        for row in sheet:
            sheet.row_dimensions[row[0].row].height = 22
    summary.freeze_panes = "A5"
    summary.row_dimensions[1].height = 28
    for cell in summary[1]:
        cell.fill = PatternFill(fill_type=None)
        cell.font = Font(name="Arial", size=15, bold=True, color="172A3A")
    summary.column_dimensions["A"].width = 25
    for letter in "BCDEFGHIJ":
        summary.column_dimensions[letter].width = 22
    # 保存后只读重开：输出绝不含公式；核对 clean 行数。
    book.save(path)
    reopened = load_workbook(path, read_only=True, data_only=False, keep_links=False)
    try:
        require(reopened["清洗结果"].max_row == audit["counts"]["clean"] + 1, "导出后 clean 行数不一致")
        require(not any(cell.data_type == "f" for sh in reopened for row in sh for cell in row), "导出文件意外包含公式")
    finally:
        reopened.close()


def export_tables(rows: list[dict], audit: dict, config: dict) -> dict:
    names = [c["name"] for c in config["columns"]]
    tables = {}
    tables["clean"] = (META + names, [metadata(r) + [r["normalized"][n] for n in names] for r in rows if r["disposition"] == "clean"])
    tables["exceptions"] = (META + ["issues_json", "normalized_json", "raw_json"], [metadata(r) + [dumps(r["issues"]), dumps(r["normalized"]), dumps(r["raw"])] for r in rows if r["disposition"] == "exception"])
    tables["duplicates"] = (META + ["kept_ref", "normalized_json"], [metadata(r) + [r["kept_ref"], dumps(r["normalized"])] for r in rows if r["disposition"] == "duplicate"])
    tables["ledger"] = (META + ["disposition", "kept_ref", "issues_json"], [metadata(r) + [r["disposition"], r.get("kept_ref", ""), dumps(r["issues"])] for r in rows])
    tables["raw_records"] = (META + ["raw_json"], [metadata(r) + [dumps(r["raw"])] for r in rows])
    group_headers = config["group_by"] + ["__record_count"] + [f"{n}__total" for n in config["amount_totals"]] + [f"{n}__missing_count" for n in config["amount_totals"]]
    group_rows = [[*[r["groups"][n] for n in config["group_by"]], r["record_count"], *[r["totals"][n] for n in config["amount_totals"]], *[r["missing_amount_counts"][n] for n in config["amount_totals"]]] for r in audit["group_summary"]]
    tables["group_summary"] = (group_headers, group_rows)
    return tables


def run(config_path: Path, input_specs: list[str], output_dir: Path) -> dict:
    raw_config = config_path.read_bytes()
    try:
        config = validate_config(json.loads(raw_config.decode("utf-8-sig")))
    except (json.JSONDecodeError, UnicodeError) as exc:
        raise InputError("配置必须为 UTF-8 JSON") from exc
    inputs = parse_inputs(input_specs, config)
    require(inputs, "至少给出一个 --input")
    output_dir = output_dir.expanduser().resolve()
    require(not output_dir.exists(), "输出路径已存在。为防覆盖，请指定一个新的 --out 目录")
    rows, manifest = read_sources(inputs, config)
    config["_manifest"] = manifest  # 仅运行期来源索引；不输出成用户规则。
    classify(rows, config)
    del config["_manifest"]
    audit = reconcile(rows, manifest, config)
    audit["config_sha256"] = hashlib.sha256(raw_config).hexdigest()
    tables = export_tables(rows, audit, config)
    output_dir.parent.mkdir(parents=True, exist_ok=True)
    staging = output_dir.parent / (".tidy-staging-" + uuid.uuid4().hex)
    staging.mkdir()
    try:
        for key, (headers, values) in tables.items():
            write_csv(staging / f"{key}.csv", headers, values, audit["export_notes"])
        write_workbook(staging / "report.xlsx", tables, audit, config)
        # 写输出后再次核对输入，避免运行期间发生的外部修改未被察觉。
        for source, (_, path) in zip(manifest, inputs):
            source["sha256_after_export"] = digest(path)
            require(source["sha256_after_export"] == source["sha256_before"], f"运行期间源文件被外部修改：{path.name}")
        (staging / "rules_used.json").write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")
        (staging / "audit.json").write_text(json.dumps(jsonable(audit), ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
        require(not output_dir.exists(), "输出路径在运行期间已被创建，未覆盖")
        os.rename(staging, output_dir)
    except Exception as exc:
        (staging / "RUN_FAILED.txt").write_text(f"此目录不是成功交付结果。错误：{exc}\n请修正规则或源结构后用新的输出目录重跑。", encoding="utf-8")
        raise InputError(f"导出失败，源文件未修改；未完成的临时输出位于 {staging}。原因：{exc}") from exc
    return audit


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True, help="显式规则 JSON")
    parser.add_argument("--input", action="append", required=True, metavar="PROFILE=FILE", help="可重复；规则中的来源配置名=csv/xlsx路径")
    parser.add_argument("--out", type=Path, required=True, help="新的输出目录，默认拒绝覆盖")
    args = parser.parse_args()
    try:
        audit = run(args.config.resolve(), args.input, args.out)
    except (InputError, OSError, ValueError, InvalidOperation) as exc:
        print(f"失败：{exc}", file=sys.stderr)
        return 2
    print(json.dumps({"output": str(args.out.resolve()), "source_record_count": audit["source_record_count"], "counts": audit["counts"], "row_reconciled": audit["row_reconciled"], "amount_reconciliation": jsonable(audit["amount_reconciliation"])}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
