from __future__ import annotations
import copy
import csv
import json
import tempfile
import unittest
from datetime import datetime, time, timedelta
from decimal import Decimal
from pathlib import Path
from openpyxl import load_workbook
from make_demo import make_demo
from tidy_data import InputError, csv_value, digest, normalize, parse_decimal_raw, run, validate_config

BASE = Path(__file__).resolve().parent


class TidyTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.csv_path, self.xlsx_path = make_demo(self.root / "inputs")
        self.config = json.loads((BASE / "examples" / "rules.json").read_text(encoding="utf-8"))
        self.config_path = self.root / "rules.json"
        self.specs = [f"cn_csv={self.csv_path}", f"en_xlsx={self.xlsx_path}"]

    def execute(self, name="out"):
        self.config_path.write_text(json.dumps(self.config, ensure_ascii=False), encoding="utf-8")
        return run(self.config_path, self.specs, self.root / name)

    def csv_rows(self):
        with self.csv_path.open(encoding="utf-8-sig", newline="") as f:
            return list(csv.reader(f))

    def put_csv(self, rows):
        with self.csv_path.open("w", encoding="utf-8-sig", newline="") as f:
            csv.writer(f).writerows(rows)

    def test_multifile_partition_amounts_and_original_hashes(self):
        before = [digest(p) for p in (self.csv_path, self.xlsx_path)]
        audit = self.execute()
        self.assertEqual(audit["source_record_count"], 14)
        self.assertEqual(audit["counts"], {"clean": 4, "exception": 8, "duplicate": 1, "blank_skipped": 1})
        money = audit["amount_reconciliation"]["amount_cny"]
        self.assertEqual(money["known_input_total"], Decimal("2649.20"))
        self.assertEqual(money["partition_totals"], {"clean": Decimal("1292.30"), "exception": Decimal("156.90"), "duplicate": Decimal("1200.00"), "blank_skipped": Decimal("0")})
        self.assertEqual(money["unavailable_input_count"], 3)
        self.assertEqual(money["difference"], 0)
        self.assertEqual(before, [digest(p) for p in (self.csv_path, self.xlsx_path)])
        self.assertEqual(len({r["ref"] for r in audit["records"]}), 14)
        dup = next(r for r in audit["records"] if r["disposition"] == "duplicate")
        self.assertEqual(dup["kept_ref"], "S001:CSV:2")
        self.assertEqual(audit["sources"][1]["sheets"], ["Orders"])

    def test_multiline_csv_has_physical_line_range_and_zero_survives(self):
        audit = self.execute()
        row = next(r for r in audit["records"] if r["normalized"]["order_id"] == "A002")
        self.assertEqual((row["row_start"], row["row_end"]), (3, 4))
        self.assertEqual(row["normalized"]["amount_cny"], Decimal("0.00"))
        self.assertEqual(row["raw"]["values"][-1], "第一行\n第二行")

    def test_formula_read_rejected_and_literal_text_output_never_formula(self):
        audit = self.execute()
        formula = next(r for r in audit["records"] if r["normalized"]["order_id"] == "A009")
        self.assertEqual(formula["disposition"], "exception")
        self.assertTrue(any(i["code"] == "formula" for i in formula["issues"]))
        self.assertIsNone(formula["parsed_amounts"]["amount_cny"])
        book = load_workbook(self.root / "out" / "report.xlsx", data_only=False)
        self.addCleanup(book.close)
        self.assertFalse(any(c.data_type == "f" for sh in book for row in sh for c in row))
        values = list(book["清洗结果"].values)
        self.assertTrue(any("=SAFE" in row for row in values))
        self.assertTrue(any("=2+2" in row for row in values))
        with (self.root / "out" / "clean.csv").open(encoding="utf-8-sig", newline="") as stream:
            self.assertTrue(any("'=SAFE" in row for row in csv.reader(stream)))
        self.assertTrue(audit["export_notes"]["csv_escaped_cells"])
        self.assertTrue(any(r["normalized"]["order_id"] == "=SAFE" for r in audit["records"]))

    def test_csv_raw_policy_preserves_text_and_negative_number_not_prefixed(self):
        self.config["csv_text_safety"] = "raw"
        audit = self.execute()
        with (self.root / "out" / "clean.csv").open(encoding="utf-8-sig", newline="") as stream:
            self.assertTrue(any("=SAFE" in row for row in csv.reader(stream)))
        self.assertEqual(audit["export_notes"]["csv_text_safety_prefixes"], 0)
        notes = {"csv_text_safety_policy":"excel_safe", "csv_text_safety_prefixes":0, "csv_escaped_cells":[]}
        self.assertEqual(csv_value(Decimal("-5.00"), notes, "test"), "-5.00")
        self.assertEqual(csv_value("-ID", notes, "test"), "'-ID")

    def test_conflicting_key_includes_valid_and_invalid_record(self):
        book = load_workbook(self.xlsx_path)
        book["Orders"]["D3"] = "bad amount"
        book.save(self.xlsx_path)
        book.close()
        audit = self.execute()
        group = [r for r in audit["records"] if r["normalized"]["order_id"] == "A004"]
        self.assertEqual(len(group), 2)
        self.assertTrue(all(r["disposition"] == "exception" for r in group))
        self.assertTrue(all(any(i["code"] == "primary_key_conflict" for i in r["issues"]) for r in group))

    def test_numeric_identifier_and_nonzero_time_are_not_guessed(self):
        audit = self.execute()
        numeric = next(r for r in audit["records"] if r["source_id"] == "S002" and r["row_start"] == 6)
        self.assertEqual(numeric["disposition"], "exception")
        self.assertIsNone(numeric["normalized"]["order_id"])
        timed = next(r for r in audit["records"] if r["normalized"]["order_id"] == "A010")
        self.assertEqual(timed["disposition"], "exception")
        self.assertEqual(timed["parsed_amounts"]["amount_cny"], Decimal(25))

    def test_ambiguous_date_formats_reject_value_and_bad_format_rejects_config(self):
        rule = copy.deepcopy(self.config["columns"][1])
        rule["formats"] = ["%Y-%m-%d", "%Y-%d-%m"]
        with self.assertRaisesRegex(ValueError, "不同结果"):
            normalize("2026-03-04", rule)
        self.config["columns"][1]["formats"] = ["%Y-%Q-%d"]
        with self.assertRaises(InputError):
            validate_config(self.config)

    def test_decimal_precision_locale_negative_boolean_and_finite_boundaries(self):
        rule = copy.deepcopy(self.config["columns"][3])
        for bad in ("1.001", "1,20.00", True, float("inf"), "NaN", "-1"):
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                normalize(bad, rule)
        self.assertEqual(normalize("1.230", rule), Decimal("1.23"))
        self.assertEqual(parse_decimal_raw("-1.001", rule), Decimal("-1.001"))
        rule.update(decimal_separator=",", thousands_separator=".", prefixes=[], suffixes=[], allow_negative=True)
        self.assertEqual(normalize("-1.234,50", rule), Decimal("-1234.50"))

    def test_duplicate_or_missing_headers_and_duplicate_mapping_fail_whole_batch(self):
        rows = self.csv_rows()
        rows[0][1] = rows[0][0]
        self.put_csv(rows)
        with self.assertRaisesRegex(InputError, "重复表头"):
            self.execute()
        self.assertFalse((self.root / "out").exists())
        self.config["sources"]["cn_csv"]["column_map"]["额外列"] = "order_id"
        with self.assertRaisesRegex(InputError, "相同目标列"):
            validate_config(self.config)

    def test_missing_sheet_and_row_limit_fail_without_partial_output(self):
        self.config["sources"]["en_xlsx"]["xlsx"]["sheets"] = ["Missing"]
        with self.assertRaisesRegex(InputError, "不存在"):
            self.execute()
        self.assertFalse((self.root / "out").exists())
        self.config["sources"]["en_xlsx"]["xlsx"]["sheets"] = ["Orders"]
        self.config["limits"]["max_rows"] = 2
        with self.assertRaisesRegex(InputError, "max_rows"):
            self.execute()

    def test_output_cannot_overwrite_and_inputs_cannot_repeat(self):
        self.execute()
        before = digest(self.root / "out" / "audit.json")
        with self.assertRaisesRegex(InputError, "输出路径已存在"):
            self.execute()
        self.assertEqual(before, digest(self.root / "out" / "audit.json"))
        self.specs.append(self.specs[0])
        with self.assertRaisesRegex(InputError, "重复输入"):
            self.execute("other")

    def test_excel_text_limits_and_precision_preserve_full_audit(self):
        rows = self.csv_rows()
        rows.append(["LONG", "2026-10-12", "线上", "1234567890123456.78", "已支付", "x"*40000+"\x01"])
        self.put_csv(rows)
        audit = self.execute()
        self.assertTrue(audit["export_notes"]["xlsx_text_escapes"])
        self.assertTrue(audit["export_notes"]["xlsx_decimal_as_text"])
        long = next(r for r in audit["records"] if r["normalized"]["order_id"] == "LONG")
        self.assertEqual(len(long["normalized"]["note"]), 40001)
        self.assertEqual(long["normalized"]["amount_cny"], Decimal("1234567890123456.78"))
        saved = json.loads((self.root / "out" / "audit.json").read_text(encoding="utf-8"))
        saved_long = next(r for r in saved["records"] if r["normalized"]["order_id"] == "LONG")
        self.assertEqual(saved_long["normalized"]["note"], "x"*40000+"\x01")

    def test_year_only_format_cannot_invent_month_or_day(self):
        self.config["columns"][1]["formats"] = ["%Y"]
        with self.assertRaisesRegex(InputError, "不能补造"):
            validate_config(self.config)

    def test_formula_versus_optional_blank_same_key_conflicts(self):
        self.config["columns"][3]["required"] = False
        rows = self.csv_rows()
        rows.append(["A009", "2026-10-09", "线上", "", "已支付", "公式金额应隔离"])
        self.put_csv(rows)
        audit = self.execute()
        group = [r for r in audit["records"] if r["normalized"]["order_id"] == "A009"]
        self.assertEqual(len(group), 2)
        self.assertTrue(all(r["disposition"] == "exception" for r in group))
        self.assertTrue(all(any(i["code"] == "primary_key_conflict" for i in r["issues"]) for r in group))

    def test_summary_notice_and_unmapped_native_excel_time_preserve_audit(self):
        self.config["notice"] = "演示\x01" + "X"*40000
        book = load_workbook(self.xlsx_path)
        sheet = book["Orders"]
        sheet["G1"] = "UnmappedTime"
        sheet["G2"] = time(12, 30)
        sheet["G3"] = timedelta(days=2, seconds=3)
        sheet["G3"].number_format = "[h]:mm:ss"
        book.save(self.xlsx_path)
        book.close()
        audit = self.execute()
        source_row = next(r for r in audit["records"] if r["source_id"] == "S002" and r["row_start"] == 2)
        self.assertEqual(source_row["raw"]["values"][6], {"excel_time":"12:30:00"})
        source_row = next(r for r in audit["records"] if r["source_id"] == "S002" and r["row_start"] == 3)
        self.assertEqual(source_row["raw"]["values"][6], {"excel_timedelta":{"days":2,"seconds":3,"microseconds":0}})
        self.assertTrue(any(n["cell"].startswith("汇总!") for n in audit["export_notes"]["xlsx_text_escapes"]))
        used = json.loads((self.root / "out" / "rules_used.json").read_text(encoding="utf-8"))
        self.assertEqual(used["notice"], self.config["notice"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
